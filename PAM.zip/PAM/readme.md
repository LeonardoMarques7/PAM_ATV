1) Escreva um programa em JavaScript que apresente uma caixa de alerta para o usuário com uma informação qualquer.

2) Crie um  script em que o usuário clicará com o botão e em seguida uma mensagem de alerta será apresentada com uma mensagem qualquer.

3)  De exemplo dos seguintes formas de trabalhar com DOM(Document Object Model), e explique:
     . document.getElementById();
     . document.getElementsByTagName();
     . document.getElementsByClassName();
     . document.querySelector();
     . document.querySelectorAll();

4) Descreva e crie exemplos com suas formas diferente eventos no javascript,segue alguns exemplo:
  . onmouseover
  . onfocus;
  . onchange;
  . entre outros; 

 5) De exemplo de os tipos de funções:
    . Função Nomeada;
    . Função Nomeada com argumento(parametro) e retorno;
    . Função com Construtor;
    . Função Literal (variável);
    . Função de Flecha(Arrow functions);

 6)  Desenvolva um script qua ao clicar no botão conta o numero de vezes clicado,
em que seja separado o HTML e o JavaScript.

 7) Crie uma função que receba uma string como parâmetro
     e retorne a mesma string com todas as letras em caixa alta.
    Utilize essa função para converter diferentes strings.

 8) Crie uma função que receba dois números como parâmetros e retorne a soma deles.
     Utilize essa função para realizar somas diferentes.
